package com.movie.model;

public class Review {

	String review;

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	public Review(String review) {
		super();
		this.review = review;
	}

	public Review() {
		super();
	}
	
}
